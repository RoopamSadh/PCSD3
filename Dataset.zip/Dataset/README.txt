#############################################################################################
DATASET: NCR survey dataset (3-Dimentional)

Description:
************
Data is collected through an extensive online survey to explore the significance of quality
parameters of Higher Educational Institutions (HEIs).  Data is collected from the National 
Capital Region (NCR) of India as it has representative Higher Educational Institutions. Survey 
invited the responses from Sciences, Social-Sciences, Medical, Technology, and Humanities
domains of twelve premier HEIs. Seven respondent categories Undergraduate, Graduate Study, 
Graduate Research, Faculty, Parents, Administrator, and Professional were identified in survey.  
##############################################################################################

The Dataset: Survey_Data.xlsx
	
 * Number of Variables: 11
 * Likert Scale used: 1- 4
 * Worksheet W_Admin contains overall survey responses (2620).
 * Worksheet WO_Admin contains survey responses excluding administrator ctegory (2533).
 * Worksheet Cluster contains the results of PCSD3 clustering over WO_Admin datasheet.	

List of Variables with their used abbreviations:

Variables					Abbreviations
*********					*************
Teaching					Teach
Graduate Outcomes				GO
Academic Flexibility				Flexi
Transparency & Accountability			Trans_Acc
Infrastructure & Resources			Infra_Res
Research					Research
Student Support Services			SSS
International Outlook				IO
Fee Structure & Financial Assistance		Fee_Ass
Academic Autonomy				Auto
Inclusivity					Inclus

List of respondent groups and their used abbreviations:

Respondent Group	    			Abbreviations
****************				*************
Administrator					Admin
Faculty						Faculty
Parents						Parent
Graduate Study					PG
Professional					Professional
Graduate Research				Researcher
Undergraduate					UG

