# This function divide the set of pattern vector on the basis of respondent categories present in the data
# Output List contain the set of patterns corrosponding to each respondent group 

Pat_div<-function(Lis1)
{
  names(Lis1) <- c("A","B","C")
  grp = Lis1$A
  D = Lis1$B
  G = Lis1$C
  x=dim(G)
  d1 = x[1]
  d2 = x[2]
  tab = table(grp)
  Cnt = as.matrix(as.vector(tab))
  Grp = unique(grp) #respondent categories
  y=dim(Grp)
  d=y[1]
  B=list()
  for(i in 1:d) #seprating out the responses of each respondent group
  {
    p =1
    r = Cnt[i]
    Group = Grp[i]
    Pat_grp = matrix(data=0, nrow = r, ncol = 1)
    Pat_D = matrix(data=0, nrow = r, ncol = d2)
    Pat_G = matrix(data=0, nrow = r, ncol = d2)
    C = B
    for(j in 1:d1)
    {
      if(grp[j]==Grp[i])
      {
        for(k in 1:d2)
        {
          Pat_grp[p] = grp[j]
          Pat_D[p,k] = D[j,k]
          Pat_G[p,k] = G[j,k]
        }
        p = p+1
      }
    }
    Lis = list(Pat_grp,Pat_D,Pat_G)
    A = list(assign(paste("G_", Group , sep = ""),Lis))
    B = append(C,A,after = length(C))
  }
  return(B)
}