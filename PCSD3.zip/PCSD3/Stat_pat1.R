# Function calculate the frequency of direction values (-1, 0, 1) in direction vectors of given respondnet group
# Output of this function is used for creating Primary Data Array (PDA)

Stat_pat1<-function(Lis1)
{
  names(Lis1) <- c("A", "B","C")
  grp = Lis1$A
  D = Lis1$B
  G = Lis1$C
  x=dim(G)
  d1=x[1]
  d2=x[2]
  q=12
  Fre = matrix(data=0,nrow=q,ncol=d2)
  Fre_pat = matrix(data = 0, nrow = 3,ncol = d2)
  for(i in 1:d1)
    {
      for(j in 1:d2)
      {
        if(G[i,j] == -1)
        {
          Fre[1,j]= Fre[1,j]+1
          Fre_pat[1,j]=Fre_pat[1,j]+1
          if(j!=d2)
          {
            if(G[i,j+1] == -1)
            {
              Fre[2,j]= Fre[2,j]+1 
            }
            else
            {
              if(G[i,j+1] == 0)
              {
                Fre[3,j]= Fre[3,j]+1
              }
              else
              {
                Fre[4,j]= Fre[4,j]+1
              }
            }
          }
          
        }
        else
        {  
          if(G[i,j] == 0)
          {
            Fre[5,j]= Fre[5,j]+1
            Fre_pat[2,j]= Fre_pat[2,j]+1
            if(j!=d2)
            {
              if(G[i,j+1] == -1)
              {
                Fre[6,j]= Fre[6,j]+1 
              }
              else
              {
                if(G[i,j+1] == 0)
                {
                  Fre[7,j]= Fre[7,j]+1
                }
                else
                {
                  Fre[8,j]= Fre[8,j]+1
                }
              }
            }
            
          }
          else
          {
            Fre[9,j]= Fre[9,j]+1
            Fre_pat[3,j]= Fre_pat[3,j]+1
            if(j!=d2)
            {
              if(G[i,j+1] == -1)
              {
                Fre[10,j]= Fre[10,j]+1 
              }
              else
              {
                if(G[i,j+1] == 0)
                {
                  Fre[11,j]= Fre[11,j]+1
                }
                else
                {
                  Fre[12,j]= Fre[12,j]+1
                }
              } 
            }
            
          }
        }
      }
    } 
  return(Fre_pat)
}