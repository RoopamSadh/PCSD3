# Finds the probability of each direction value in each respondent group
# Confirmity Constraint alpha set as 0.85

Stat_pat3<-function(tab)
{
  T = tab
  A = dim(T)
  d1 = A[1]
  d2 = A[2]
  P = d2*3
  Pr= 0.85
  x = 1
  y = 1
  U = matrix(data = 0,nrow=P,ncol=d2)
  for(j in 1:d2)
  {
    for(k in 1:d2)
    {
      if(k==j)
      {
        U[x,k] = -1
        U[x+1,k] = 0
        U[x+2,k] = 1
      }
      else
      {
        l=0
        m=0
        while(l<=2)
        { 
          z = y+m
          BS = T[z,j]
          H1 = T[z,k]
          H2 = T[z+1,k]
          H3 = T[z+2,k]
          if(BS==0)
          {
            U[x+l,k] = 0
          }
          else
          {
            if(H2==0)
            {
              if(H3>=H1)
              {
                G = H3/BS
                if(Pr<=G)
                {
                  U[x+l,k] = 1
                }
                else
                {
                  U[x+l,k] = G
                }
              }
              else
              {
                G = H1/BS
                if(Pr<=G)
                {
                  U[x+l,k] = -1
                }
                else
                {
                  U[x+l,k] = -G
                }
              }
            }
            else
            {
              if(H1>=H2)
              {
                if(H1>=H3)
                {
                  G = H1/BS
                  if(Pr<= G)
                  {
                    U[x+l,k] = -1
                  }
                  else
                  {
                    a=H1-H3
                    b=a+H2
                    c=a/b
                    U[x+l,k] = -c
                  }
                }
                else
                {
                  G=H3/BS
                  if(Pr<=G)
                  {
                    U[x+l,k] = 1
                  }
                  else
                  {
                    a=H3-H1
                    b=a+H2
                    c=a/b
                    U[x+l,k] = c
                  }
                }
              }
              else
              {
                if(H2>=H3)
                {
                  G = H2/BS
                  if(Pr<= G)
                  {
                    U[x+l,k] = 0
                  }
                  else
                  {
                    if(H3>=H1)
                    {
                      a=H3-H1
                      b=a+H2
                      c=a/b
                      U[x+l,k] = c
                    }
                    else
                    {
                      a=H1-H3
                      b=a+H2
                      c=a/b
                      U[x+l,k] = -c
                    }
                  }
                }
                else
                {
                  G = H3/BS
                  if(Pr<=G)
                  {
                    U[x+l,k] = 1
                  }
                  else
                  {
                    a=H3-H1
                    b=a+H2
                    c=a/b
                    U[x+l,k] = c
                    
                  }
                }
              }
            }
          }
          l = l+1
          m = m+3
        }
      }
    }
    x=x+3
    y=y+9
  }
  return(U)
}