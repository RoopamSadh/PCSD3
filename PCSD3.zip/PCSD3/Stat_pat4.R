# Creation of Primary Data Array (PDA)
# Conformity constraint alpha is set to 0.85
# Calculation of probabilities based on the frequecy counts

Stat_pat4<-function(sat)
{
  S = sat
  A = dim(S)
  d1 = A[1]
  d2 = A[2]
  Pr= 0.85
  V = matrix(data = 0,nrow=1,ncol=d2)
  for(k in 1:d2)
  {
    H1 = S[1,k]
    H2 = S[2,k]
    H3 = S[3,k]  
    BS = H1+H2+H3
    if(H2==0)
    {
      if(H3>=H1)
      {
        G = H3/BS
        if(Pr<=G)
        {
          V[k] = 1
        }
        else
        {
          V[k] = G
        }
      }
      else
      {
        G = H1/BS
        if(Pr<=G)
        {
          V[k] = -1
        }
        else
        {
          V[k] = -G
        }
      }
    }
    else
    {
      if(H1>=H2)
      {
        if(H1>=H3)
        {
          G = H1/BS
          if(Pr<= G)
          {
            V[k] = -1
          }
          else
          {
            a=H1-H3
            b=a+H2
            c=a/b
            V[k] = -c
          }
        }
        else
        {
          G=H3/BS
          if(Pr<=G)
          {
            V[k] = 1
          }
          else
          {
            a=H3-H1
            b=a+H2
            c=a/b
            V[k] = c
          }
        }
      }
      else
      {
        if(H2>=H3)
        {
          G = H2/BS
          if(Pr<= G)
          {
            V[k] = 0
          }
          else
          {
            if(H3>=H1)
            {
              a=H3-H1
              b=a+H2
              c=a/b
              V[k] = c
            }
            else
            {
              a=H1-H3
              b=a+H2
              c=a/b
              V[k] = -c
            }
          }
        }
        else
        {
          G = H3/BS
          if(Pr<=G)
          {
            V[k] = 1
          }
          else
          {
            a=H3-H1
            b=a+H2
            c=a/b
            V[k] = c
            
          }
        }
      }
    }
  }
  return(V)
}