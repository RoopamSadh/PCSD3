# Function calculate the absolute distance of each direction vector of the raw survey data with the reference vector of each respondent group
# Store the index of the refrence vector that has smallest distance with the direction vector in consideration
# Returns vector containg the index finds (cluster number) for each direction vector of survey data

matc<-function(Lis1,Ref)
{
  names(Lis1) <- c("A","B","C")
  grp = Lis1$A
  D = Lis1$B
  G = Lis1$C
  x=dim(G)
  d1 = x[1]
  d2 = x[2]
  y = dim(Ref)
  d3 = y[1]
  d4 = y[2]
  dif = matrix(data=0,nrow=1,ncol=d2)
  tdif = matrix(data=0,nrow=d3,ncol=1)
  wt = matrix(data=0,nrow=d1,ncol=1)
  tem = 0
  for(i in 1:d1)
  {
    for(j in 1:d3)
    {
      for(k in 1:d2)
      {
        dif[1,k]= abs(G[i,k]-Ref[j,k])
        tem = tem+dif[1,k]
      }
      tdif[j] = tem
      tem = 0
    }
    wt[i]= which.min(tdif) #shortest absolute distance
  }
  return(wt)
}