# Creation of Secondary Data Array (SDA)
# Function select each variable one by one (iteratively).
# Claculate frequency counts of direction values in other remaining variables corrosponding to each direction value of chosen variable

Stat_pat2<-function(Lis1)
{
  names(Lis1) <- c("A", "B","C")
  grp = Lis1$A
  D = Lis1$B
  G = Lis1$C
  x=dim(G)
  d1=x[1]
  d2=x[2]
  q=d2*9
  p=d2*3
  l=1
  m=4
  n=7
  Fre = matrix(data=0,nrow=q,ncol=d2)
  prob = matrix(data=0,nrow=p,ncol=d2)
  for(i in 1:d2)
  {
    if(i!=1)
    {
      l = l+9
      m = l+3
      n = l+6
    }
    for(j in 1:d1)
    {
      if(G[j,i]==-1)
      {
        Fre[l,i]=Fre[l,i]+1
      }
      else
      {
        if(G[j,i]==0)
        {
          Fre[m,i]=Fre[m,i]+1
        }
        else
        {
          Fre[n,i]=Fre[n,i]+1
        }
      }
      for(k in 1:d2)
      {
          if(G[j,i]==-1)
          {
            if(k!=i)
            {
              if(G[j,k]==-1)
              {
                Fre[l,k]= Fre[l,k]+1
              }
              else
              {
                if(G[j,k]==0)
                {
                  Fre[l+1,k]= Fre[l+1,k]+1
                }
                else
                {
                  Fre[l+2,k]= Fre[l+2,k]+1
                }
              }
            }
          }
          else
          {
            if(G[j,i]==0)
            {
              if(k!=i)
              {
                if(G[j,k]==-1)
                {
                  Fre[m,k]= Fre[m,k]+1
                }
                else
                {
                  if(G[j,k]==0)
                  {
                    Fre[m+1,k]= Fre[m+1,k]+1
                  }
                  else
                  {
                    Fre[m+2,k]= Fre[m+2,k]+1
                  }
                }
                
              }
            }
            else
            {
              if(k!=i)
              {
                if(G[j,k]==-1)
                {
                  Fre[n,k]= Fre[n,k]+1
                }
                else
                {
                  if(G[j,k]==0)
                  {
                    Fre[n+1,k]= Fre[n+1,k]+1
                  }
                  else
                  {
                    Fre[n+2,k]= Fre[n+2,k]+1
                  }
                }
                
              }
              
            }
          }
        
      }
    }
    
  }
  return(Fre)
}